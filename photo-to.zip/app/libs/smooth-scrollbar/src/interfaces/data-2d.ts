// 2-dimension data set
export type Data2d = {
  x: number,
  y: number,
};
